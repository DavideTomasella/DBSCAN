/*
$Revision: 1.3 $
$Date: 2005/06/27 10:58:00 $
$Author: mtuonone $
$Name:  $
$Id: cb2txt.h,v 1.3 2005/06/27 10:58:00 mtuonone Exp $
*/
 
#if ! defined(__CB2TXT_H)
#define __CB2TXT_H

#define MAXFILENAME 40
#define MAX_1BYTE 255
#define MAX_2BYTE 65535
#define MAX_3BYTE 1000000
#define DEFAULT_MINMAX_FILE "minmax.txt"
#define MINMAX_FILENAME_SEPARATOR ';'

#define FormatNameTXT "txt"
#define FormatNameSC  "sc"
      
#endif /* __CB2TXT_H */
