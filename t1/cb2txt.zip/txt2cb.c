/*
$Revision: 1.4 $
$Date: 2007/06/20 08:01:32 $
$Author: mtuonon $
$Name:  $
$Id: txt2cb.c,v 1.4 2007/06/20 08:01:32 mtuonon Exp $
*/
 
/******************************************************************

    TXT2CB.C

    Ismo K�rkk�inen, Marko Tuononen

    Text to codebook conversion tool.

******************************************************************/


#define ProgName       "TXT2CB"
#define VersionNumber  "Version 0.30"
#define LastUpdated    "27.06.2005" /* mt */

#define PARAMETER_FILENAME_COUNT 3
#define FACTFILE  "txt2cb.fac"
 
#include <math.h>
#include <float.h>

#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

#define ABS(a) ((a) < 0 ? -(a) : (a))

/* works nicely, when a >= 0 */
#define ROUND(a) ( ((a) - floor(a)) < 0.5 ? (floor(a)) : (floor(a)+1) )


#include "parametr.c"
#include "cb.h"
#include "file.h"
#include "interfc.h"
#include "fvec.h"
#include "cb2txt.h"

 
void PrintInfo() {
    PrintMessage("%s\t%s\t%s\n\n"
        "Text to codebook conversion tool\n"
        "Usage: %s [%coption] <input text file> <output codebook> "
        "[minmax file]\n"
        "For example: %s in.txt out.cb minmax.txt\n\n"
        "Options:\n", ProgName, VersionNumber, LastUpdated, ProgName, 
        OPTION_SYMBOL, ProgName);
    PrintOptions();
    PrintMessage("\n");
}


void DetermineMinMaxFilename(char *minmax, char* out, int scaling) {
    char* c;
    
    if (! *minmax) {  /* user didn't give minmax file */
        switch (scaling) {
            case 0: /* no scaling, so no need for minmax file */
                break;
            
            case 1: /* using default file name */
                strcpy(minmax, DEFAULT_MINMAX_FILE);
                break;
            
            case 2: /* get name from out file */
                strcpy(minmax, out);
                c = strrchr(minmax, '.');
                if (c != NULL) {
                    *c = '\0';
                }           
                strcat(minmax, ".");
                strcat(minmax, FormatNameSC);
                break;
        }
    } else if (!scaling) {  /* no scaling, so no need for minmax file */
        *minmax = '\0';
    }
}


void CheckParameters(char *minmax, char *in, char *out, int ow) {
    /* input text file doesn't exist */
    if (!ExistFile(in)) {
        ErrorMessage("\nERROR: Input text file doesn't exist: %s\n\n", in);
        ExitProcessing(FATAL_ERROR);
    }
    
    /* output codebook exists and we are told not to overwrite */
    if (ExistFile(out) && !ow) {
        ErrorMessage("\nERROR: Output codebook already exists: %s\n\n", out);
        ExitProcessing(FATAL_ERROR);
    }
    
    /* minmax file exists and we are told not to overwrite */
    if (*minmax && ExistFile(minmax) && !ow) {
        ErrorMessage("\nERROR: Minmax file already exists: %s\n\n", minmax);
        ExitProcessing(FATAL_ERROR);
    }
}


int ReadInputData(float ***Data, int *count, int *dim, char *InName, int ql) {
    FILE *f;
    int ok;
    
    f = fopen(InName, "rt");
    ok = fvReadSet(Data, count, dim, f);
    fclose(f);
    
    if (ok && ql) {
        if (ok-1) {
            PrintMessage("WARNING: %d vectors had missing ", ok-1);
            PrintMessage("attributes and they were ignored.\n\n");
        }
        PrintMessage("Input text file %s contained ", InName);
        PrintMessage("%i vectors of dimensionality %i\n", *count, *dim);
    }
    
    return ok;       
}        


float **FindMinMax(float **Data, int count, int dim, int ql) {
    int j;
    float **MinMax;
   
    MinMax = fvNewSet(dim, 2);
    
    for (j = 0; j < dim; j++) {
        MinMax[j][0] = fvSetMinimum(Data, count, j);
        MinMax[j][1] = fvSetMaximum(Data, count, j);
        
        if (Value(QuietLevel) > 1)
            PrintMessage("Range for %d. attribute is [%g,%g]\n", 
                j+1, MinMax[j][0], MinMax[j][1]);
    }
     
    return MinMax;
}


int DetermineMaxval(float **Data, int count, int dim, int *bytes) {
    int maxval;
    float val = 0;
    
    switch (*bytes) {
        case 1: maxval = MAX_1BYTE; break;
        case 2: maxval = MAX_2BYTE; break;
        case 3: maxval = MAX_3BYTE; break;
        
        default:    /* automatic choice */
            val = fvSetTotalMaximum(Data, count, dim);
            val = val - fvSetTotalMinimum(Data, count, dim);
            
            if (val <= MAX_1BYTE) {
                maxval = MAX_1BYTE;
                *bytes = 1;
            } else if (val <= MAX_2BYTE) {
                maxval = MAX_2BYTE;
                *bytes = 2;
            } else {
                maxval = MAX_3BYTE;
                *bytes = 3;
            }
            
            break;
    }
    return maxval;
}


void WriteData2CB(float **Data, int count, int dim, char *OutName, 
float **MinMax, char* MinMaxName, int bytes, int scaling, int ql) {
    CODEBOOK CB;
    int maxval, i, j;
    float scale, totalMin, totalMax;
    char GenMethod[MAXFILENAME+1] = "\0";
    
    maxval = DetermineMaxval(Data, count, dim, &bytes);
    
    /* is it possible not to scale? */
    if (!scaling) {
        totalMin = fvSetTotalMinimum(Data, count, dim);
        totalMax = fvSetTotalMaximum(Data, count, dim);
        
        if ((totalMax > maxval) || (totalMin < 0)) {
            ErrorMessage("ERROR: Cannot save vectors without scaling!\n");
            ExitProcessing(FATAL_ERROR);
        }
    }

    /* saving minmax name to GenerationMethod-field, if needed */    
    if (scaling >= 2) {
        strcpy(GenMethod, MinMaxName);
        GenMethod[strlen(GenMethod)]   = MINMAX_FILENAME_SEPARATOR;
        GenMethod[strlen(GenMethod)+1] = '\0';
        strcat(GenMethod, ProgName);
    } else {
        strcpy(GenMethod, ProgName);
    }
    
    CreateNewTrainingSet(&CB, count, dim, 1, bytes, 0, maxval, 0, GenMethod);
    
    /* set all vector frequencies to 1 */
    for (i = 0; i < count; i++) {
        VectorFreq(&CB, i) = 1;
    }
        
    for (j = 0; j < dim; j++) {
        if (scaling) {
            if (MinMax[j][1] - MinMax[j][0] < FLT_EPSILON)
                scale = 0.0F;
            else
                scale = maxval / (MinMax[j][1] - MinMax[j][0]);
            
            for (i = 0; i < count; i++) {           
                /* scaling attributes to interval [0,maxval] */
                VectorScalar(&CB, i, j) = ROUND((Data[i][j] - MinMax[j][0]) * scale);
            }
            
        } else {
            for (i = 0; i < count; i++) {           
                /* no scaling at all; just rounding, if needed */
                VectorScalar(&CB, i, j) = ROUND(Data[i][j]);
            }
        }
    }
    CB.Preprocessing = scaling;
        
    TotalFreq(&CB) = count;
    WriteCodebook(OutName, &CB, 1);
    FreeCodebook(&CB);
    
    if (ql) {
        PrintMessage("\nVectors were saved to output codebook %s\n", OutName);
        if (scaling) {
            PrintMessage("All attributes were scaled to range [0,%d]\n", maxval);
        } else {
            PrintMessage("All attributes were rounded to integers and no scaling was done.\n");
        }
    }
}


int SaveMinMax(float **MinMax, int size, char *MinMaxName) {
    FILE *f;
    int ok;
    
    f = fopen(MinMaxName, "w");
    ok = !fvWriteSet(MinMax, size, 2, f);
    fclose(f);
    
    return ok;
}


int main(int argc, char** argv) {
    int ok, count, dim;
    float **MinMax, **Data;
    char MinMaxName[MAXFILENAME] = "\0";
    char InName[MAXFILENAME] = "\0";
    char OutName[MAXFILENAME] = "\0";
    ParameterInfo paraminfo[PARAMETER_FILENAME_COUNT] = { 
        { InName, FormatNameTXT, 0, INFILE },
        { OutName, FormatNameCB, 0, OUTFILE },
        { MinMaxName, FormatNameTXT, 1, OUTFILE } };
                
    ParseParameters(argc, argv, PARAMETER_FILENAME_COUNT, paraminfo);
    DetermineMinMaxFilename(MinMaxName, OutName, Value(ScalingAndMinMaxFile));
    CheckParameters(MinMaxName, InName, OutName, Value(OverWrite));
    
    if (Value(QuietLevel) >1) { 
        PrintMessage("%s %s %s\n\n", ProgName, VersionNumber, LastUpdated);
        PrintSelectedOptions();
        PrintMessage("\n");
    }
    
    /* we read given (textual) input data... */
    ok = ReadInputData(&Data, &count, &dim, InName, Value(QuietLevel));
    
    if (!ok) {
        ErrorMessage("\nERROR: Failed to read input text file: %s\n\n", InName);
        ExitProcessing(FATAL_ERROR);
    }
    
    /* ...and find min and max values for each attribute separately */
    MinMax = FindMinMax(Data, count, dim, Value(QuietLevel));    
    
    /* we save normalized and scaled data to the codebook */ 
    WriteData2CB(Data, count, dim, OutName, MinMax, MinMaxName, 
        Value(BytesPerElement), Value(ScalingAndMinMaxFile), Value(QuietLevel));
    
    /* if minmax file given, we save min and max values 
       (for descaling and denormalization purposes) */
    if (*MinMaxName) {
        ok = SaveMinMax(MinMax, dim, MinMaxName);
        
        if (!ok) {
            ErrorMessage("\nERROR: Failed to write minmax file: %s\n\n", MinMaxName);
            ExitProcessing(FATAL_ERROR);
        } else if (Value(QuietLevel)) {
            PrintMessage("\nOriginal range data was saved to minmax file %s\n", MinMaxName);
        }
    }
    
    fvDeleteSet(MinMax, dim);
    fvDeleteSet(Data, count);
    
    return EVERYTHING_OK;
}
