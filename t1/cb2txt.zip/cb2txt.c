/*
$Revision: 1.5 $
$Date: 2007/01/25 12:19:32 $
$Author: mtuonon $
$Name:  $
$Id: cb2txt.c,v 1.5 2007/01/25 12:19:32 mtuonon Exp $
*/

/******************************************************************
 
    CB2TXT.C

    Ismo K�rkk�inen, Marko Tuononen

    Codebook to text conversion tool.

******************************************************************/

#define ProgName       "CB2TXT"
#define VersionNumber  "Version 0.30"
#define LastUpdated    "27.06.2005" /* mt */
 
#define PARAMETER_FILENAME_COUNT 3
#define FACTFILE  "cb2txt.fac"
#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

#include <math.h>
#include <limits.h>
#include <float.h>
#include "parametr.c"
#include "cb.h"
#include "file.h"
#include "interfc.h"
#include "fvec.h"
#include "cb2txt.h"


void PrintInfo() {
    PrintMessage("%s\t%s\t%s\n\n"
        "Codebook to text conversion tool\n"
        "Usage: %s [%coption] <input codebook> <output text file> "
        "[minmax file]\n"
        "For example: %s in.cb out.txt minmax.txt\n\n"
        "Options:\n", ProgName, VersionNumber, LastUpdated, ProgName, 
        OPTION_SYMBOL, ProgName);
    PrintOptions();
    PrintMessage("\n");
}


void DetermineMinMaxFilename(char* minmax, CODEBOOK CB, int ql) {
    char* c;
    
    if (! *minmax) {  /* user didn't give minmax file */
        switch (CB.Preprocessing) {
            case 0: /* no scaling, so no need for minmax file */
                break;
            
            case 1: /* using default file name */
                strcpy(minmax, DEFAULT_MINMAX_FILE);
                break;
            
            case 2: /* get name from GenerationMethod-field */
                strncpy(minmax, CB.GenerationMethod, MAXFILENAME);
                c = strchr(minmax, (int)MINMAX_FILENAME_SEPARATOR);                
                if (c != NULL) {
                    *c = '\0';                    
                } else {
                    *minmax = '\0';
                    if (ql) {
                        ErrorMessage("\nWARNING: No minmax file was found");
                        ErrorMessage(", so descaling isn't done.\n\n"); 
                    }
                }
                break;
        }
        
    } else if (CB.Preprocessing <= 0) {  /* no descaling needed, but user wants */
        if (ql) {
            ErrorMessage("\nWARNING: Descaling forced by user.\n"); 
        }
    }
}


void CheckParameters(char *in, char *out, int ow) {   
    /* output text file exists and we are told not to overwrite */
    if (ExistFile(out) && !ow) {
        ErrorMessage("\nERROR: Output text file already exists: %s\n\n", out);
        ExitProcessing(FATAL_ERROR);
    }

    /* input codebook doesn't exist */
    if (!ExistFile(in)) {
        ErrorMessage("\nERROR: Input codebook doesn't exist: %s\n\n", in);
        ExitProcessing(FATAL_ERROR);
    }
}


int ReadMinMax(float ***MinMax, int *dim, char *MinMaxName) {
    FILE *f;
    int ok, k;
    
    f = fopen(MinMaxName, "rt");
    if (!f) return 0;
    
    ok = fvReadSet(MinMax, dim, &k, f);
    fclose(f);
    
    return (ok == 1) && (k == 2);    
}


void PrintRangeData(float **MinMax, int dim, int ql) {
    int i;
    
    if (ql > 1) {
        for (i = 0; i < dim; i++) {
            PrintMessage("Original range for %d. attribute is [%g,%g]\n", 
                i+1, MinMax[i][0], MinMax[i][1]);
        }
        PrintMessage("\n");
    }
}

int GetMaxval(CODEBOOK *CB) {
    int maxval;
    
    switch (CB->BytesPerElement) {
        case 1 : maxval = MAX_1BYTE; break;            
        case 2 : maxval = MAX_2BYTE; break;
        case 3 : maxval = MAX_3BYTE; break;        
        default:
            maxval = 0; 
            ErrorMessage("\nERROR: CB->BytesPerElement value unsupported.\n\n");
            ExitProcessing(FATAL_ERROR);
            break;
    }
    
    return maxval;
}


int CalcPrec(int *precArr, char* MinMaxName, float **MinMax, int dim, 
int maxval, int prec) {
    int i, tmp, maxprec = -1;
    double resolution;
    
    if (*MinMaxName && !prec) {
        for (i = 0; i < dim; i++) {
            resolution  = (MinMax[i][1] - MinMax[i][0]) / maxval;
            tmp         = (int)log10(resolution);
            
            if (tmp < 0)
                precArr[i] = 1 - tmp;
            else
                precArr[i] = 0;
                
            if (precArr[i] > maxprec)
                maxprec = precArr[i];
        }
        
    } else {
        maxprec = prec;        
        for (i = 0; i < dim; i++) 
            precArr[i] = prec;
    }
    
    return maxprec;
}


int CalcMaxlen(char *MinMaxName, float **MinMax, int dim, int maxval, 
int prec) {
    int i;
    float max = FLT_MIN;
    
    if (*MinMaxName) {
        for (i = 0; i < dim; i++) {
            if (MinMax[i][1] > max) 
                max = MinMax[i][1];
        }
    } else {
        max = maxval;
    }
    
    return (int)log10((double)max) + prec + 4;
}


float DeScale(CODEBOOK *CB, int i, int j, char* MinMaxName, 
float **MinMax, int maxval) {
    float val, scale;
    
    if (*MinMaxName) {
        scale = (MinMax[j][1] - MinMax[j][0]) / maxval;        
        val   = MinMax[j][0] + VectorScalar(CB, i, j)*scale;
        
    } else {
        val   = VectorScalar(CB, i, j);
    }
    
    return val;
}


int SaveCB2TXT(CODEBOOK *CB, char *OutName, char *MinMaxName, 
float **MinMax, int freq, int prec) {
    int i, j, k, n, ok, maxval, maxlen, maxprec;
    int precArr[VectorSize(CB)];
    float **tmp;
    FILE *f;
    
    if (freq) {
        tmp = fvNewSet(TotalFreq(CB), VectorSize(CB));
        
    } else {
        tmp = fvNewSet(BookSize(CB), VectorSize(CB));
    }
    
    maxval  = GetMaxval(CB);
    maxprec = CalcPrec(precArr, MinMaxName, MinMax, VectorSize(CB), maxval, prec);
    maxlen  = CalcMaxlen(MinMaxName, MinMax, VectorSize(CB), maxval, maxprec);
    
    n = 0;
    for (i = 0; i < BookSize(CB); i++) {
        k = 0;
        do {
            for (j = 0; j < VectorSize(CB); j++) {
                /* we do descaling and denormalizing 
                   (if original range information given) */
                tmp[n][j] = DeScale(CB, i, j, MinMaxName, MinMax, maxval);
                /* PrintMessage("%d %d: %f\n", n, j, tmp[n][j]); */
            }
            n++;
            k++;
        } while ((k < VectorFreq(CB, i)) && freq);       
    }
    
    /* we save data to text file */
    f = fopen(OutName, "w"); 
    
    ok = !fvWriteSetWithPrec(tmp, n, VectorSize(CB), f, maxlen, precArr);
    fclose(f);
    fvDeleteSet(tmp, n);
    
    return ok;
}


int main(int argc, char** argv) {
    int ok, dim;
    float **MinMax;
    CODEBOOK CB;    
    char InName[MAXFILENAME] = "\0";
    char OutName[MAXFILENAME] = "\0";
    char MinMaxName[MAXFILENAME] = "\0";
    ParameterInfo paraminfo[PARAMETER_FILENAME_COUNT] = { 
        { InName, FormatNameCB, 0, INFILE },
        { OutName, FormatNameTXT, 0, OUTFILE },
        { MinMaxName, FormatNameTXT, 1, INFILE } };       
    
    ParseParameters(argc, argv, PARAMETER_FILENAME_COUNT, paraminfo);
    CheckParameters(InName, OutName, Value(OverWrite));
    
    if (Value(QuietLevel) > 1) { 
        PrintMessage("%s %s %s\n\n", ProgName, VersionNumber, LastUpdated);
        PrintSelectedOptions();
        PrintMessage("\n");
    }

    /* we read given input codebook... */
    ReadCodebook(InName, &CB);
    if (Value(QuietLevel))  
        PrintMessage("Codebook %s was read\n", InName);
    
    if (!Value(NO_DeScaling)) {
        DetermineMinMaxFilename(MinMaxName, CB, Value(QuietLevel));
    
    } else if (*MinMaxName) {
        if (Value(QuietLevel)) {
            ErrorMessage("\nWARNING: NO DESCALING was selected, omitting ");
            ErrorMessage("minmax file %s\n\n", MinMaxName);
        }
        *MinMaxName = '\0';
    }
    
    /* ...and original range information, if given */
    if (*MinMaxName) {
        ok = ReadMinMax(&MinMax, &dim, MinMaxName);
        
        if (!ok) {
            PrintMessage("\nWarning: failed to read/find minmax file: "
                "%s\n", MinMaxName);
            PrintMessage("Proceeding without original range information.\n\n");
            MinMaxName[0] = '\0'; 
 
        } else if (dim != VectorSize(&CB)) {
            ErrorMessage("\nERROR: Dimensions doesn't agree: minmax "
                "file %s vs. codebook %s\n\n", MinMaxName, InName);
            ExitProcessing(FATAL_ERROR);
            
        } else if (Value(QuietLevel)) {
            PrintMessage("\nOriginal range data was read from minmax "
                "file %s\n", MinMaxName);
            PrintRangeData(MinMax, dim, Value(QuietLevel));
        }
    }
    
    /* we save (descaled and denormalized) data to the text file */
    ok = SaveCB2TXT(&CB, OutName, MinMaxName, MinMax, Value(Frequencies), 
             Value(Precision));
    
    if (!ok) {
        ErrorMessage("\nERROR: Failed to write text file: %s\n\n", OutName);
        ExitProcessing(FATAL_ERROR);
        
    } else if (Value(QuietLevel)) {
        PrintMessage("Codebook was saved to text file %s\n", OutName);
        if (*MinMaxName) {
            PrintMessage("All attributes was descaled to original range.\n");
        }
    }
    
    if (*MinMaxName) {
        fvDeleteSet(MinMax, dim);
    }
    FreeCodebook(&CB);
        
    return EVERYTHING_OK;
}

